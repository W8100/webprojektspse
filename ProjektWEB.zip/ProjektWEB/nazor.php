<?php

// Připojení k databázi
$db_host = "localhost"; // Nahraďte hostitelem databáze
$db_user = "root"; // Nahraďte jménem uživatele databáze
$db_password = ""; // Nahraďte heslem uživatele databáze
$db_name = "projektwebjankovic"; // Nahraďte názvem vaší databáze

$connection = mysqli_connect($db_host, $db_user, $db_password, $db_name);

// Kontrola připojení
if (!$connection) {
    die("Nepodařilo se připojit k databázi: " . mysqli_connect_error());
}

// Získání dat z formuláře
$jmeno = isset($_POST["jmeno"])
    ? mysqli_real_escape_string($connection, $_POST["jmeno"])
    : "";
$email = isset($_POST["email"])
    ? mysqli_real_escape_string($connection, $_POST["email"])
    : "";
$komentar = isset($_POST["komentar"])
    ? mysqli_real_escape_string($connection, $_POST["komentar"])
    : "";

// Vložení dat do databáze
$sql = "INSERT INTO nazor (jmeno, email, komentar) VALUES ('$jmeno', '$email', '$komentar')";

if (mysqli_query($connection, $sql)) {
    echo "";
} else {
    echo "Při ukládání vašeho názoru došlo k chybě: " .
        mysqli_error($connection);
}

// Zavření připojení k databázi
mysqli_close($connection);
?>



<!DOCTYPE html>
    <html lang="cs">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Webová stránka</title>
                    <link rel="stylesheet" href="style.css">
                    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
                    
        </head>
    <body>
<header class="navbar navbar-expand-lg navbar-dark bg-dark">
     <a class="navbar-brand" href="#">Nákupní seznam</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMenu" aria-controls="navbarNavAltMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

 <div class="collapse navbar-collapse text-center" id="navbarNavAltMenu">
 
    <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php">Informace</a></li>
        <li class="nav-item active"><a class="nav-link" href="main.php">Aplikace</a></li>
        <li class="nav-item text-center"><a class="nav-link" class="text-center" href="nazor.php">Názor</a></li>
    </ul>
 </div>
 <a href="main.php">
  <img class="logo" src="./favicon3.jpg" alt="logo">
 </a>
</header>
 
 <main>
    <section>
    <h2 class="text-center">Názor</h2>
        <form class="form-group" action="nazor.php" method="post">
            <label for="jmeno">Jméno:</label>
            <input type="text" class="form-control" id="jmeno" name="jmeno" required>
            <label for="email">E-mail:</label>
            <input type="email" class="form-control" id="email" name="email" required>
            <label for="komentar">Komentář:</label>
        <textarea class="form-control" id="komentar" name="komentar" rows="3" required></textarea>
    <br>
            <button type="submit" class="btn btn-primary">Odeslat</button>
        </form>
    </section>
 </main>
<footer class="fixed-bottom bg-dark text-white py-3 mt-5">
    <div class="container text-center">
    <p>&copy; 2024 Petr Jankovič</p>
    </div>
 
 </footer>

</body>
</html>
<!--

CREATE TABLE nazor (
  id INT AUTO_INCREMENT PRIMARY KEY,
  jmeno VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  komentar TEXT NOT NULL,
  
);



 -->