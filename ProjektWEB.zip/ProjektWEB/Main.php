<!DOCTYPE html>
<html lang="cs">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="author" content="Petr Jankovič">
    <meta name="keywords" content="HTML, PHP, CSS">
    <meta name="description" content="Nákupní seznam">
  <title>Webová stránka</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="icon" type="image/png" href="./favicon3.jpg">
</head>
<body>
 


<header class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Nákupní seznam</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMenu" aria-controls="navbarNavAltMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMenu">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="index.php">Informace</a></li>
                <li class="nav-item active"><a class="nav-link" href="main.php">Aplikace</a></li>
                <li class="nav-item"><a class="nav-link" href="nazor.php">Názor</a></li>
            </ul>
        </div>
        <a href="main.php">
  <img class="logo" src="./favicon3.jpg" alt="logo">
        </a>
    </header>
  <main class="d-flex flex-column min-height-75vh">
    <section>
      <h2 class="text-center">Úvodní stránka</h2>
     
    </section>
    <section>
      <h2 class="text-center" >Aktuální datum:
      <?php echo date('Y-m-d'); ?></h2>
    </section>
    <section>
      <h2>Seznam položek</h2>

      <?php

      // Připojení k databázi

      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "projektwebjankovic"; // Zkontrolujte název databáze



      $conn = new mysqli($servername, $username, $password, $dbname);
      if (isset($_POST['readData'])) {
        readFromDB(); // 
      } elseif (isset($_POST['writeData'])) {
          writeDataToDB(); 
      }
      
      


      // Kontrola připojení
      if ($conn->connect_error) {
        die('Nepodařilo se připojit k databázi: ' . $conn->connect_error);
      }

      function readFromDB() {
        global $conn; 
        $sql = "SELECT * FROM shopping_list"; 
    
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            // vytvoří a zoprazí zapsaná data
            echo "<table border='1'>";
            echo "<tr><th>Název</th><th>Množství</th><th>Kategorie</th><th>Poznámka</th><th>Zakoupeno</th></tr>";
    
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>" . $row['category'] . "</td>";
                echo "<td>" . $row['note'] . "</td>";
                echo "<td>" . ($row['purchased'] == 1 ? 'Ano' : 'Ne') . "</td>";
                echo "</tr>";
            }
    
            echo "</table>";
        } else {
            echo "Nebyly nalezeny žádné položky.";
        }
    }


    function writeDataToDB() {
      global $conn; 
  
      $name = $_POST['name']; 
      $quantity = $_POST['quantity'];
      if (empty($name) || empty($quantity)) {
        echo "Vyplňte prosím pole 'Název' a 'Množství'.";
        exit; // Stop further processing
      }
      $category = $_POST['category'];
      $note = $_POST['note'];
      $purchased = isset($_POST['purchased']) ? 1 : 0; 
  
     $sql = "INSERT INTO shopping_list (name, quantity, category, note, purchased) VALUES ('$name', $quantity, '$category', '$note', $purchased)";

     

      if ($conn->query($sql) === TRUE) {
       
        echo '<p id="podtrzeni">';
        echo "Data byla vložena do databáze.";
        echo "<p>";
      
    } else {
        echo "Nepodařilo se vložit data do databáze: " . $conn->error;
    }
}







      // Zavření připojení k databázi
      $conn->close();

      ?>

      <form action="main.php" method="post" class="container mt-5">
  <div class="form-group">
    <label for="name">Název:</label>
    <input type="text" id="name" name="name" class="form-control" required>
  </div>

  <div class="form-group">
    <label for="quantity">Množství:</label>
    <input type="number" id="quantity" name="quantity" class="form-control" required>
  </div>

  <div class="form-group">
    <label for="category">Kategorie:</label>
    <input type="text" id="category" name="category" class="form-control">
  </div>

  <div class="form-group">
    <label for="note">Poznámka:</label>
    <textarea id="note" name="note" class="form-control"></textarea>
  </div>

  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="purchased" name="purchased">
    <label class="form-check-label" for="purchased">Zakoupeno</label>
  </div>

  <div class="text-center">  
    <button type="submit" name="writeData" onclick="writeDataToDB()" class="btn btn-primary">Výpis do databáze</button>
    <button type="submit" name="readData" class="btn btn-secondary">Výpis z databáze</button>
  </div>
  
  
</form>
    </section>
  </main>
  </body>
  
  <footer class="fixed-bottom bg-dark text-white py-3 mt-5">
        <div class="container text-center">
            <p>&copy; 2024 Petr Jankovič</p>
        </div>
        </div>
    </footer>

</html> 
<!--

VYTVORENI DATABAZE POMOCI SQL

CREATE TABLE seznam.shopping_list (
  id INT AUTO_INCREMENT PRIMARY KEY,  /* Optional: Auto-incrementing ID for each item */
  name VARCHAR(255) NOT NULL,
  quantity INT,
  category VARCHAR(100),
  note TEXT,
  purchased TINYINT(1) DEFAULT 0 /* 0 for not purchased, 1 for purchased */
);



 -->