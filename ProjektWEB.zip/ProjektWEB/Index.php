<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nákupní seznam - Informace a návod</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="./favicon3.jpg">

</head>
<body>
    <header class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="main.php">Nákupní seznam</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMenu" aria-controls="navbarNavAltMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMenu">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="index.php">Informace</a></li>
                <li class="nav-item active"><a class="nav-link" href="main.php">Aplikace</a></li>
                <li class="nav-item"><a class="nav-link" href="nazor.php">Názor</a></li>
            </ul>
        </div>
        <a href="main.php">
  <img class="logo" src="./favicon3.jpg" alt="logo">
        </a>
    </header>

    <main class="container mt-5">
        <h1 class="text-center">Nákupní seznam - Váš praktický pomocník</h1>

        <section class="mb-5">
            <h2 class="h4">O aplikaci</h2>
            <p>Nákupní seznam je webová aplikace, která vám pomůže s organizací a správou vašich nákupů. Usnadňuje nakupování a šetří vám čas i peníze.</p>
            <ul>
                <li>Vytvářejte a spravujte seznamy položek, které potřebujete koupit.</li>
                <li>Označujte položky jako "zakoupené" a sledujte svůj pokrok.</li>
                <li>Přidávejte poznámky a kategorie k položkám pro lepší přehlednost.</li>
                <li>Zobrazujte si aktuální datum a mějte tak přehled o tom, kdy jste naposledy nakupovali.</li>
            </ul>
        </section>

        <section class="mb-5">
            <h2 class="h4">Jak používat aplikaci</h2>
            <ol>
                <li>Vytvořte si seznam položek, které potřebujete koupit.</li>
                <li>Pro každou položku zadejte název, množství, kategorii a případně poznámku.</li>
                <li>Označte položky jako "zakoupené", jakmile je koupíte.</li>
                <li>Pravidelně si procházejte seznam a aktualizujte ho.</li>
                <li>Využijte datum k tomu, abyste si udrželi přehled o tom, kdy jste naposledy nakupovali.</li>
            </ol>
        </section>
    </main>

    <footer class="fixed-bottom bg-dark text-white py-3 mt-5">
        <div class="container text-center">
            <p>&copy; 2024 Petr Jankovič</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.
